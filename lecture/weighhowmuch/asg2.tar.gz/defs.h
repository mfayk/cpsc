#ifndef defs_h_
#define defs_h_
#include <stdio.h>
//this is my header file for all the prototypes

float otherweight(float x,int y);

#endif
